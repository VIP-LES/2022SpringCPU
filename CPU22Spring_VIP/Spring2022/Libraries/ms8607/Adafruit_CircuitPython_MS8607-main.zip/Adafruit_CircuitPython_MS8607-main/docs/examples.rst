Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ms8607_simpletest.py
    :caption: examples/ms8607_simpletest.py
    :linenos:
