Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/tsl2591_simpletest.py
    :caption: examples/tsl2591_simpletest.py
    :linenos:
