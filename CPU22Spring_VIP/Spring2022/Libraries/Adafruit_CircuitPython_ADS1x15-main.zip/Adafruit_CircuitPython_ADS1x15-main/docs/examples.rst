Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ads1x15_simpletest.py
    :caption: examples/ads1x15_ads1015_simpletest.py
    :linenos:

.. literalinclude:: ../examples/ads1x15_ads1115_simpletest.py
    :caption: examples/ads1x15_ads1115_simpletest.py
    :linenos:
